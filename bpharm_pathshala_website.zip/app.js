// B.Pharm Pathshala — configure these two values from Supabase > Project Settings > API.
const SUPABASE_URL = "YOUR_SUPABASE_PROJECT_URL";
const SUPABASE_ANON_KEY = "YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY";
const BUCKET = "pharmacy-pdfs";
const configured = SUPABASE_URL.startsWith("https://") && !SUPABASE_URL.includes("YOUR_") && !SUPABASE_ANON_KEY.includes("YOUR_");
const db = configured && window.supabase ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;
const $ = s => document.querySelector(s);
let resources = [];
const terms = { "B.Pharm": ["Semester 1","Semester 2","Semester 3","Semester 4","Semester 5","Semester 6","Semester 7","Semester 8"], "D.Pharm": ["Year 1","Year 2"] };
function toast(message){const el=$("#toast");el.textContent=message;el.style.display="block";setTimeout(()=>el.style.display="none",3500)}
function escapeHtml(v=""){return String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function updateTerms(){const course=$("#courseFilter").value;$("#termLabel").firstChild.textContent=course==="B.Pharm"?"Semester":"Year";$("#termFilter").innerHTML=terms[course].map(t=>`<option>${t}</option>`).join("");renderResources()}
function renderResources(){
 const course=$("#courseFilter").value, syllabus=$("#syllabusFilter").value, term=$("#termFilter").value, q=$("#searchInput").value.toLowerCase().trim();
 const filtered=resources.filter(r=>r.course===course&&r.syllabus===syllabus&&r.term===term&&(`${r.title} ${r.subject} ${r.description||""} ${r.kind}`).toLowerCase().includes(q));
 $("#resultCount").textContent=`${filtered.length} resource${filtered.length===1?"":"s"}`;
 $("#notesGrid").innerHTML=filtered.length?filtered.map(r=>`<article class="note-card"><div class="note-icon">${r.kind==="Important Questions"?"✎":"▤"}</div><div class="tags"><span class="tag">${escapeHtml(r.kind)}</span><span class="tag">${escapeHtml(r.syllabus)}</span></div><h3>${escapeHtml(r.title)}</h3><p>${escapeHtml(r.subject)} · ${escapeHtml(r.term)}</p>${r.description?`<p>${escapeHtml(r.description)}</p>`:""}<div class="card-actions"><a href="${escapeHtml(r.pdf_url)}" target="_blank" rel="noopener">View PDF ↗</a><a href="${escapeHtml(r.pdf_url)}" target="_blank" rel="noopener" download>Download ↓</a></div></article>`).join(""):`<div class="empty">${configured?"No resources match these filters yet. Admin can upload the first PDF.":"Website preview is ready. Connect Supabase and upload PDFs to display live resources."}</div>`;
}
async function loadResources(){
 if(!db){resources=demoResources();renderResources();return}
 const {data,error}=await db.from("resources").select("*").order("created_at",{ascending:false});
 if(error){console.error(error);resources=[];renderResources();toast("Could not load resources. Check Supabase table and policies.");return}
 resources=data||[];renderResources();
}
function demoResources(){return [
 {id:"demo1",title:"Sample: Fluorimetry Notes",course:"B.Pharm",syllabus:"New AKTU",term:"Semester 7",subject:"Instrumental Methods of Analysis",kind:"Notes PDF",description:"Upload your own PDF from the admin panel after configuring Supabase.",pdf_url:"#"},
 {id:"demo2",title:"Sample: Pharmaceutical Chemistry",course:"D.Pharm",syllabus:"PCI",term:"Year 1",subject:"Pharmaceutical Chemistry",kind:"Important Questions",description:"Demo card — replace with real study resources.",pdf_url:"#"}
].filter(r=>r.course===$("#courseFilter").value&&r.syllabus===$("#syllabusFilter").value&&r.term===$("#termFilter").value)}
$("#courseFilter").addEventListener("change",updateTerms);
["syllabusFilter","termFilter","searchInput"].forEach(id=>$("#"+id).addEventListener(id==="searchInput"?"input":"change",renderResources));
$("#adminOpen").addEventListener("click",async()=>{if(!db){$("#loginDialog").showModal();$("#loginMessage").textContent="";return}const {data}=await db.auth.getSession();if(data.session){showAdmin(true)}else $("#loginDialog").showModal()});
$("#loginClose").addEventListener("click",()=>$("#loginDialog").close());
$("#loginForm").addEventListener("submit",async e=>{e.preventDefault();if(!db){$("#loginMessage").textContent="First add your Supabase URL and publishable/anon key in app.js.";return}const fd=new FormData(e.currentTarget);const {error}=await db.auth.signInWithPassword({email:fd.get("email"),password:fd.get("password")});if(error){$("#loginMessage").textContent=error.message;return}$("#loginDialog").close();showAdmin(true);toast("Admin signed in.")});
function showAdmin(show){$("#adminPanel").hidden=!show;if(show){$("#adminPanel").scrollIntoView({behavior:"smooth"});$("#adminStatus").textContent="Signed in. Add a PDF resource below."}}
$("#logoutBtn").addEventListener("click",async()=>{if(db)await db.auth.signOut();$("#adminPanel").hidden=true;toast("Signed out.")});
$("#resourceForm").addEventListener("submit",async e=>{
 e.preventDefault();if(!db){toast("Configure Supabase first.");return}
 const {data:{session}}=await db.auth.getSession();if(!session){toast("Please sign in as admin.");return}
 const fd=new FormData(e.currentTarget), file=fd.get("pdf");if(!file||file.type!=="application/pdf"){toast("Please select a PDF file.");return}
 const path=`${crypto.randomUUID()}-${file.name.replace(/[^a-zA-Z0-9._-]/g,"_")}`;
 $("#adminStatus").textContent="Uploading PDF…";
 const {error:uploadError}=await db.storage.from(BUCKET).upload(path,file,{contentType:"application/pdf",upsert:false});
 if(uploadError){$("#adminStatus").textContent=uploadError.message;return}
 const {data:urlData}=db.storage.from(BUCKET).getPublicUrl(path);
 const row={title:fd.get("title"),course:fd.get("course"),syllabus:fd.get("syllabus"),term:fd.get("term"),subject:fd.get("subject"),kind:fd.get("kind"),description:fd.get("description"),pdf_url:urlData.publicUrl,storage_path:path};
 const {error:insertError}=await db.from("resources").insert(row);
 if(insertError){await db.storage.from(BUCKET).remove([path]);$("#adminStatus").textContent=insertError.message;return}
 e.currentTarget.reset();$("#adminStatus").textContent="PDF uploaded successfully.";await loadResources();toast("Resource published.");
});
if(db)db.auth.onAuthStateChange((event,session)=>{if(event==="SIGNED_OUT")$("#adminPanel").hidden=true});
updateTerms();loadResources();