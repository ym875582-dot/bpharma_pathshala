# B.Pharm Pathshala — website starter

Includes the supplied B.Pharm Pathshala logo, responsive homepage, course/syllabus/semester filters, PDF cards, Supabase login and an admin upload form.

## 1. Configure Supabase
1. Create/open a project at https://supabase.com.
2. Open **Project Settings → API** (or Connect) and copy the Project URL and publishable/anon key.
3. Open `app.js` and replace:
   - `YOUR_SUPABASE_PROJECT_URL`
   - `YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY`
4. In Supabase **SQL Editor**, run all of `supabase.sql`.
5. In **Storage → New bucket**, create a bucket named `pharmacy-pdfs`. Set it public if you want public PDF links.
6. In **Authentication → Users**, create your own admin user. Never put a service-role/secret key in this website.

## 2. Security before launch
The included SQL is a starter for learning/testing, not production-complete authorization. The example authenticated insert/delete policies allow any signed-in user to modify the resource list. Before public launch, replace them with policies that check a dedicated admin role/user ID, and add matching Storage policies restricting upload/delete to that admin. Keep the anon/publishable key only in the frontend; never expose the service-role key. Turn on email confirmation only after SMTP/site URL/redirect URLs are configured correctly.

## 3. Run locally
Open `index.html` in a browser to view the layout. Without Supabase configuration, it displays demo cards only; login/upload requires a configured project. For local development, a simple static server is preferable to opening the file directly.

## 4. Publish on GitHub Pages
1. Create a GitHub repository named `bpharm-pathshala`.
2. Upload `index.html`, `style.css`, `app.js`, `supabase.sql`, `README.md`, and the `assets` folder.
3. In repository **Settings → Pages**, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
4. Wait for the Pages URL to appear. Add that URL to Supabase **Authentication → URL Configuration → Site URL / Redirect URLs**.
5. Re-test login, resource list and PDF upload using your Pages URL.

## 5. Add notes
Sign in using the account created in Supabase. Open Admin Login → upload a PDF → choose course, syllabus, semester/year and subject → Upload resource. Only upload PDFs you own or have permission to distribute.

## Current limitations
- Demo subject/semester options are intentionally broad; populate resources according to the applicable current AKTU/PCI syllabus.
- Search filters existing resources; it is not a question-answer search engine.
- This starter does not include an in-browser question editor or delete button. Important Questions can be uploaded as PDFs.
